using System;
using System.Data;
using System.IO;

namespace CSV_Testing_2
{
    public partial class Form1 : Form
    {
        List<string> titles = new List<string>();
        List<string> authors = new List<string>();
        List<string> genres = new List<string>();
        List<DateTime> publicationDates = new List<DateTime>();
        List<string> isbns = new List<string>();
        List<int> pageCounts = new List<int>();
        List<string> publishers = new List<string>();
        List<string> languages = new List<string>();
        List<decimal> prices = new List<decimal>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Step 1: Read the CSV file into a DataTable
            DataTable dataTable = new DataTable();
            string csvFilePath = "Data/MOCK_DATA.csv";// Specify the path to your CSV file
            string[] lines = File.ReadAllLines(csvFilePath);

            if (lines.Length > 0)
            {
                // Assuming the first line contains the column headings
                string[] headers = lines[0].Split(',');
                foreach (string header in headers)
                {
                    dataTable.Columns.Add(header);
                }

                // Assuming the data starts from the second line
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] data = lines[i].Split(',');
                    DataRow row = dataTable.NewRow();
                    for (int j = 0; j < headers.Length; j++)
                    {
                        row[j] = data[j];
                    }
                    dataTable.Rows.Add(row);
                }
            }

            // Step 2: Convert DataTable into lists
            foreach (DataRow row in dataTable.Rows)
            {
                titles.Add(row["title"].ToString());
                authors.Add(row["author"].ToString());
                genres.Add(row["genre"].ToString());
                publicationDates.Add(Convert.ToDateTime(row["publication_date"]));
                isbns.Add(row["isbn"].ToString());
                pageCounts.Add(Convert.ToInt32(row["page_count"]));
                publishers.Add(row["publisher"].ToString());
                languages.Add(row["language"].ToString());  // No conversion needed for language

                // Add error handling for price conversion
                decimal price;
                if (decimal.TryParse(row["price"].ToString(), out price))
                {
                    prices.Add(price);
                }
                else
                {
                    // Handle invalid price value, for example, set it to a default value
                    prices.Add(0m); // Set to 0 or any other default value
                }
            }

        }

        private void btnGenNew_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int length = titles.Count;
            int selectedIndex = rand.Next(length);

            lblTitle.Text = titles[selectedIndex].ToString().Replace("\"", "");
            lblAuthor.Text = authors[selectedIndex].ToString().Replace("\"", "");
            lblGenre.Text = genres[selectedIndex].ToString().Replace("\"", "");
            lblISBN.Text = isbns[selectedIndex].ToString().Replace("\"", "").Insert(3,"-").Insert(5,"-").Insert(8, "-").Insert(15,"-");
            lblLang.Text = languages[selectedIndex].ToString().Replace("\"", "");
            lblPageCount.Text = pageCounts[selectedIndex].ToString().Replace("\"", "");
            if (prices[selectedIndex] == 0)
            {
                lblPrice.Text = "---";
            }
            else
            {
                lblPrice.Text = prices[selectedIndex].ToString("C").Replace("\"", "");
            }
            
            lblPub.Text = publishers[selectedIndex].ToString().Replace("\"", "");
            string MonthDay = publicationDates[selectedIndex].ToString("M");
            string WeekDay = publicationDates[selectedIndex].ToString("ddd");
            string Year = publicationDates[selectedIndex].ToString("yyyy");
            lblPubDate.Text = WeekDay + ", " + MonthDay + ", " + Year;
        }
    }
}
